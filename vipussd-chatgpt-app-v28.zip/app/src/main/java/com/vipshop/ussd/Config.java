package com.vipshop.ussd;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Config {
    /* Token só para a versão do dono. Nas versões dos clientes fica vazio. */
    static final String TOKEN_DONO = "";

    static SharedPreferences p(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static String servidor(Context c) { return p(c).getString("servidor", "http://78.154.103.14:16701"); }
    static String token(Context c) {
        String d = SecureTokenStore.get(c, "token_disp");
        if (!d.isEmpty()) return d;
        String token = SecureTokenStore.get(c, "token");
        return token.isEmpty() ? TOKEN_DONO : token;
    }
    static boolean guardarToken(Context c, String token) {
        return SecureTokenStore.put(c, "token", token == null ? "" : token.trim());
    }
    static boolean guardarTokenDispositivo(Context c, String token) {
        return SecureTokenStore.put(c, "token_disp", token == null ? "" : token.trim());
    }
    static boolean pronto(Context c) { return !servidor(c).isEmpty(); }

    static boolean botAtivo(Context c) { return p(c).getBoolean("bot_ativo", true); }
    static void setBotAtivo(Context c, boolean ativo) {
        p(c).edit().putBoolean("bot_ativo", ativo).apply();
    }

    static void guardarLicenca(Context c, String ate) { p(c).edit().putString("licenca_ate", ate).apply(); }
    static String licencaAte(Context c) { return p(c).getString("licenca_ate", ""); }

    static boolean licencaAtiva(Context c) {
        String a = licencaAte(c);
        if (a.isEmpty()) return false;
        if (a.equalsIgnoreCase("permanente")) return true;
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            return new Date().before(f.parse(a.substring(0, 19)));
        } catch (Exception e) {
            return false;
        }
    }

    static boolean vozAtiva(Context c) { return p(c).getBoolean("voz", true); }
    static void setVoz(Context c, boolean on) { p(c).edit().putBoolean("voz", on).apply(); }
}
