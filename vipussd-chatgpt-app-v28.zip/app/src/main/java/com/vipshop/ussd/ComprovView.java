package com.vipshop.ussd;

import android.content.Context;
import android.graphics.Color;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/* Comprovativos recebidos pelo bot (M-Pesa e e-Mola). Só leitura. */
public class ComprovView extends ScrollView {
    private final LinearLayout corpo;

    public ComprovView(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
        corpo = new LinearLayout(c);
        corpo.setOrientation(LinearLayout.VERTICAL);
        corpo.setPadding(UI.dp(c, 20), UI.dp(c, 12), UI.dp(c, 20), UI.dp(c, 20));
        addView(corpo);
        carregar();
    }

    void carregar() {
        if (!Config.pronto(getContext())) {
            mostrar(null, "Indisponível neste aparelho.");
            return;
        }
        new Thread(() -> {
            try {
                JSONArray arr = new JSONArray(Api.pedir(getContext(), "GET", "/app/comprovativos", null));
                post(() -> mostrar(arr, null));
            } catch (Exception e) {
                post(() -> mostrar(null, "Não foi possível carregar os comprovativos."));
            }
        }).start();
    }

    private void mostrar(JSONArray arr, String erro) {
        corpo.removeAllViews();
        corpo.addView(UI.texto(getContext(), "Comprovativos", 20, UI.OURO));
        if (erro != null) {
            corpo.addView(UI.texto(getContext(), erro, 13, UI.VERMELHO));
            return;
        }
        if (arr == null || arr.length() == 0) {
            corpo.addView(UI.texto(getContext(), "Ainda não há comprovativos.", 13, UI.CINZA));
            return;
        }
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault());
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            LinearLayout caixa = UI.cartao(getContext());
            long data = o.optLong("data", 0);
            String quando = data > 0 ? fmt.format(new Date(data)) : "-";
            String metodo = o.isNull("metodo") ? "" : o.optString("metodo").toUpperCase(Locale.ROOT) + " · ";
            caixa.addView(UI.texto(getContext(), metodo + o.optString("valor", "?") + " MT · " + quando, 15, Color.WHITE));
            caixa.addView(UI.texto(getContext(), "Referência: " + o.optString("id", "-"), 12, UI.CINZA));
            String estado = o.optBoolean("invalidado") ? "Invalidado" : o.optBoolean("usado") ? "Já usado" : "Disponível";
            int cor = o.optBoolean("invalidado") ? UI.VERMELHO : o.optBoolean("usado") ? UI.CINZA : UI.VERDE;
            caixa.addView(UI.texto(getContext(), estado, 13, cor));
            corpo.addView(caixa);
        }
    }
}
